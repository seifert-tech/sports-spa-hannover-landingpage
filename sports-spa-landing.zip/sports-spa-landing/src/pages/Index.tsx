import React from "react";
import { SportsSpaPage } from "@/components/SportsSpaPage";

const Index = () => {
  return <SportsSpaPage />;
};

export default Index;
