import React from "react";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import { IMAGES } from "@/lib/constants";

interface DealSectionProps {
  onOpenModal: () => void;
}

export const DealSection: React.FC<DealSectionProps> = ({ onOpenModal }) => {
  return (
    <section className="py-20 px-4 bg-[#080808]">
      <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <p className="text-xs font-bold text-red-500 italic uppercase tracking-widest">
              UNSER FRÜHJAHRS DEAL
            </p>
            <h2 className="text-3xl sm:text-5xl font-black uppercase text-white leading-tight mt-1">
              TRAINIERE 3 MONATE GRATIS*!
            </h2>
          </div>

          <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
            Letzte Chance: Sichere dir jetzt unser{" "}
            <strong className="text-white italic">limitiertes</strong>{" "}
            Frühjahrs‒Angebot und trainiere die ersten 3 Monate komplett gratis
            bei deinem Sports &amp; Spa!
          </p>

          <p className="text-neutral-300 text-sm sm:text-base">
            Anschließend trainierst du für <strong>59,99€/4-wtl.*</strong>{" "}
            weiter!
          </p>

          <div className="bg-red-950/40 border border-red-900/60 p-4 rounded-xl text-xs sm:text-sm text-red-200">
            Wenn du dich{" "}
            <strong className="text-white">online anmeldest</strong> sparst du
            dir sogar noch die Aufnahmegebühr in Höhe von{" "}
            <strong className="text-white">50€</strong>!
          </div>

          <p className="text-xs text-neutral-400 italic">
            Beeile dich, denn dieses Angebot gilt nur für kurze Zeit.
          </p>

          <ul className="space-y-3 pt-2">
            <li className="flex items-center gap-3 text-sm text-white font-medium">
              <div className="w-5 h-5 rounded-full bg-red-600 flex items-center justify-center text-white shrink-0">
                <Check className="w-3.5 h-3.5" />
              </div>
              Ladies Only Area
            </li>
            <li className="flex items-center gap-3 text-sm text-white font-medium">
              <div className="w-5 h-5 rounded-full bg-red-600 flex items-center justify-center text-white shrink-0">
                <Check className="w-3.5 h-3.5" />
              </div>
              Wellness &amp; Spa mit Saunawelt
            </li>
            <li className="flex items-center gap-3 text-sm text-white font-medium">
              <div className="w-5 h-5 rounded-full bg-red-600 flex items-center justify-center text-white shrink-0">
                <Check className="w-3.5 h-3.5" />
              </div>
              Spare die komplette Aufnahmegebühr (50€)
            </li>
          </ul>

          <div className="pt-2">
            <Button
              onClick={onOpenModal}
              className="bg-red-600 hover:bg-red-700 text-white font-black py-6 px-8 text-base uppercase tracking-wider rounded-xl animate-pulse-glow"
            >
              ANGEBOT SICHERN
            </Button>
          </div>
        </div>

        <div className="relative">
          <div className="relative mx-auto max-w-md rounded-2xl overflow-hidden border border-red-900/40 shadow-2xl shadow-red-950/60">
            <img
              src={IMAGES.ATHLETE_IMAGE}
              alt="Sports & Spa High Performance Training"
              className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-transparent to-transparent opacity-60" />
            <div className="absolute bottom-4 left-4 right-4 bg-neutral-950/80 backdrop-blur-md p-3 rounded-lg border border-neutral-800 text-xs">
              <p className="font-bold text-white uppercase italic">
                Sports &amp; Spa Premium Club
              </p>
              <p className="text-neutral-400 text-[11px]">
                Echte Fitness, Wellness &amp; Mindset
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
