import React from "react";

export const Footer: React.FC = () => {
  return (
    <footer className="py-12 px-4 bg-black border-t border-neutral-900 text-neutral-500 text-[11px] leading-relaxed">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="space-y-2 border-b border-neutral-900 pb-6 text-neutral-400">
          <p className="font-semibold text-neutral-300">*Sonderkonditionen:</p>
          <p>
            Es gilt ein reduzierter Mitgliedsbeitrag in Höhe von 0,00 € statt
            €59,99 / 4 wöchentlich für die ersten 3 Monate. Mitgliedsvertrag mit
            24 Monaten Laufzeit; Leistungen nach Basis-Mitgliedschaft;
            ordentliche Kündigung mit Frist von 1 Monat zum Laufzeitende.
            Buchungsintervall: 4-wöchentlich montags per SEPA-Lastschrift.
            Service- und Trainingspauschale (49,99 € / Abbuchung: halbjährlich)
            fällt erst ab dem 7. Monat an und wird jeweils zum 1. des Monats
            eingezogen. Die 14-Tage-Testphase gilt für Vertragsschlüsse im
            Rahmen der Sonderaktion zusätzlich zu gesetzlichen Widerrufsrechten,
            die hiervon unberührt bleiben. Innerhalb von 14 Tagen kann
            schriftlich (per Post/vor Ort) vom Vertrag zurückgetreten werden. Es
            fallen keine zusätzlichen Kosten oder Nutzungsersatz nach Rückgabe
            der Clubkarte innerhalb von 14 Tagen an. Ergänzend gelten die
            Allgemeinen Geschäftsbedingungen von Sports &amp; Spa.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <p className="font-bold text-white text-sm">
              SPORTS &amp; SPA HANNOVER
            </p>
            <p className="text-neutral-500 text-xs">Südstadt &amp; List</p>
          </div>
          <div className="flex items-center gap-6 text-xs text-neutral-400">
            <a
              href="https://www.sportsundspa.de/datenschutz"
              target="_blank"
              rel="noreferrer"
              className="hover:text-white transition-colors"
            >
              Datenschutz
            </a>
            <a
              href="https://www.sportsundspa.de/impressum"
              target="_blank"
              rel="noreferrer"
              className="hover:text-white transition-colors"
            >
              Impressum
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
