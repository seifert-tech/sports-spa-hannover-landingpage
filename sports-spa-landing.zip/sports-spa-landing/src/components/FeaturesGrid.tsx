import React from "react";
import { Dumbbell, Sparkles, Flame, Heart } from "lucide-react";

export const FeaturesGrid: React.FC = () => {
  return (
    <section className="py-16 px-4 bg-[#080808]">
      <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-neutral-900/60 border border-neutral-800/80 rounded-2xl p-6 text-center space-y-4 hover:border-red-900/60 transition-colors">
          <div className="w-12 h-12 rounded-full bg-red-950 border border-red-800 text-red-500 flex items-center justify-center mx-auto">
            <Dumbbell className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-red-500 italic uppercase tracking-wider">
              VIELSEITIGE
            </p>
            <h3 className="text-xl font-black uppercase text-white">KURSE</h3>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed">
            Bei Sports &amp; Spa erwarten dich vielseitige Kurse, darunter
            Pilates, Fatburner, Yoga und Fitness Boxen.
          </p>
        </div>

        <div className="bg-neutral-900/60 border border-neutral-800/80 rounded-2xl p-6 text-center space-y-4 hover:border-red-900/60 transition-colors">
          <div className="w-12 h-12 rounded-full bg-red-950 border border-red-800 text-red-500 flex items-center justify-center mx-auto">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-red-500 italic uppercase tracking-wider">
              WELLNESS
            </p>
            <h3 className="text-xl font-black uppercase text-white">
              &amp; Spa
            </h3>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed">
            Tank dich bei einem Body&amp;Mind- oder Yoga-Kurs auf oder entspann
            dich in unserem erstklassigen Wellnessbereich mit Sauna und
            Außenbecken (Südstadt).
          </p>
        </div>

        <div className="bg-neutral-900/60 border border-neutral-800/80 rounded-2xl p-6 text-center space-y-4 hover:border-red-900/60 transition-colors">
          <div className="w-12 h-12 rounded-full bg-red-950 border border-red-800 text-red-500 flex items-center justify-center mx-auto">
            <Flame className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-red-500 italic uppercase tracking-wider">
              ANTI
            </p>
            <h3 className="text-xl font-black uppercase text-white">
              Aging Training
            </h3>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed">
            Krafttraining steht bei Sports &amp; Spa im Mittelpunkt aus gutem
            Grund: Es bildet die Basis für Vitalität, Flexibilität und
            Gesundheit - das beste Anti-Aging.
          </p>
        </div>

        <div className="bg-neutral-900/60 border border-neutral-800/80 rounded-2xl p-6 text-center space-y-4 hover:border-red-900/60 transition-colors">
          <div className="w-12 h-12 rounded-full bg-red-950 border border-red-800 text-red-500 flex items-center justify-center mx-auto">
            <Heart className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-red-500 italic uppercase tracking-wider">
              LADIES ONLY
            </p>
            <h3 className="text-xl font-black uppercase text-white">Area</h3>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed">
            Entdecke in unserer Pink Area speziell für Frauen konzipierte
            Trainingsgeräte, um deine Problemzonen anzugehen - Ladies Get Ready!
          </p>
        </div>
      </div>
    </section>
  );
};
