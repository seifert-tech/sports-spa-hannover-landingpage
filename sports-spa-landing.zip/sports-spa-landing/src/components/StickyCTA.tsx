import React from "react";
import { Button } from "@/components/ui/button";
import { Gift, ArrowRight } from "lucide-react";

interface StickyCTAProps {
  onOpenModal: () => void;
}

export const StickyCTA: React.FC<StickyCTAProps> = ({ onOpenModal }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-neutral-950/95 border-t border-red-900/50 p-2.5 backdrop-blur-md sm:hidden shadow-2xl">
      <div className="flex items-center justify-between gap-2 max-w-md mx-auto">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-red-950 border border-red-800 text-red-500 flex items-center justify-center shrink-0 animate-pulse">
            <Gift className="w-4 h-4" />
          </div>
          <div>
            <p className="text-[11px] font-black uppercase text-white leading-tight">
              3 MONATE 0€
            </p>
            <p className="text-[9px] text-emerald-400 font-semibold">
              + 50€ Aufnahme gespart
            </p>
          </div>
        </div>
        <Button
          onClick={onOpenModal}
          className="bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase py-2.5 px-4 rounded-lg flex items-center gap-1 shadow-lg shadow-red-950 shrink-0"
        >
          <span>Sichern</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Button>
      </div>
    </div>
  );
};
