import React from "react";
import { Button } from "@/components/ui/button";
import { IMAGES } from "@/lib/constants";
import { WhatsAppButton } from "@/components/WhatsAppButton";

interface HeroSectionProps {
  timeLeft: {
    days: string;
    hours: string;
    minutes: string;
    seconds: string;
  };
  onOpenModal: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  timeLeft,
  onOpenModal,
}) => {
  return (
    <section className="relative min-h-screen flex flex-col overflow-hidden bg-black px-4 pb-20 sm:pb-16">
      {/* Header Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src={IMAGES.HERO_BG}
          alt="Sports & Spa Background"
          className="w-full h-full object-cover object-center sm:object-top"
        />
        {/* Mobile: dunklerer unterer Bereich, damit Text unter dem Gesicht lesbar ist */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/90 pointer-events-none sm:bg-gradient-to-b sm:from-black/40 sm:via-transparent sm:to-black/80" />
      </div>

      {/* Top Header Logo – auf Handy kleiner */}
      <div className="relative z-20 w-full flex justify-center pt-3 sm:pt-4">
        <img
          src={IMAGES.LOGO_WHITE}
          alt="Sports & Spa Hannover"
          className="h-7 sm:h-12 md:h-14 object-contain drop-shadow-lg"
        />
      </div>

      {/* Spacer: auf Handy wird der Inhalt nach unten geschoben, unter das Gesicht */}
      <div className="flex-1 min-h-[20vh] sm:min-h-[10vh]" />

      {/* Center Headline & Countdown & CTA */}
      <div className="relative z-20 max-w-4xl mx-auto w-full text-center space-y-5 sm:space-y-8 py-4">
        {/* Banner Graphic Title */}
        <div className="flex justify-center px-2">
          <img
            src={IMAGES.HERO_BANNER}
            alt="3 MONATE GRATIS TRAINIEREN"
            className="max-h-24 sm:max-h-44 md:max-h-56 object-contain filter drop-shadow-[0_20px_40px_rgba(0,0,0,0.95)]"
          />
        </div>

        {/* Subtitle Countdown */}
        <div className="space-y-3">
          <p className="text-[10px] sm:text-sm font-bold uppercase tracking-widest text-white/90 drop-shadow">
            NUR NOCH GÜLTIG BIS:
          </p>
          <div className="flex items-center justify-center gap-1.5 sm:gap-4 text-white">
            {[
              { v: timeLeft.days, l: "Tage" },
              { v: timeLeft.hours, l: "Std" },
              { v: timeLeft.minutes, l: "Min" },
              { v: timeLeft.seconds, l: "Sek" },
            ].map((item, i) => (
              <React.Fragment key={item.l}>
                <div className="text-center min-w-[44px] sm:min-w-[80px]">
                  <div className="text-2xl sm:text-5xl font-black tracking-tight text-white drop-shadow-[0_4px_10px_rgba(0,0,0,0.9)]">
                    {item.v}
                  </div>
                  <div className="text-[9px] sm:text-xs text-neutral-300 font-medium uppercase">
                    {item.l}
                  </div>
                </div>
                {i < 3 && (
                  <span className="text-2xl sm:text-4xl font-black text-white/80">
                    :
                  </span>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* CTA Button + WhatsApp */}
        <div className="space-y-3 pt-2 sm:pt-4 max-w-md mx-auto">
          <Button
            onClick={onOpenModal}
            className="w-full sm:w-auto bg-red-600 hover:bg-red-700 text-white font-black text-sm sm:text-xl py-5 sm:py-7 px-8 sm:px-12 rounded-xl uppercase tracking-wider shadow-2xl transition-transform hover:scale-105 active:scale-95 animate-pulse-glow"
          >
            ANGEBOT SICHERN
          </Button>

          <WhatsAppButton variant="hero" />
        </div>
      </div>

      {/* Bottom Scroll Indicator */}
      <div className="relative z-20 hidden sm:flex flex-col items-center justify-center text-white/70 animate-bounce pb-2">
        <span className="text-xs uppercase tracking-widest font-semibold mb-1">
          Mehr erfahren
        </span>
        <svg
          className="w-5 h-5"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 9l-7 7-7-7"
          />
        </svg>
      </div>
    </section>
  );
};
