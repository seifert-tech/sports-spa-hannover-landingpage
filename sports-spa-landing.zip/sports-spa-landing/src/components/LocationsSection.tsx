import React, { useState } from "react";
import { MapPin, Clock, Phone } from "lucide-react";

export const LocationsSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"suedstadt" | "list">("suedstadt");

  return (
    <section className="py-16 px-4 bg-[#0a0a0a] border-t border-neutral-900">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <p className="text-xs font-bold text-red-500 italic uppercase tracking-widest">
            2X IN HANNOVER
          </p>
          <h2 className="text-3xl sm:text-4xl font-black uppercase text-white">
            UNSERE STANDORTE
          </h2>
        </div>

        <div className="flex justify-center gap-2">
          <button
            onClick={() => setActiveTab("suedstadt")}
            className={`px-6 py-2.5 rounded-lg text-sm font-bold uppercase transition-all ${
              activeTab === "suedstadt"
                ? "bg-red-600 text-white shadow-lg shadow-red-950"
                : "bg-neutral-900 text-neutral-400 hover:text-white"
            }`}
          >
            Hannover Südstadt
          </button>
          <button
            onClick={() => setActiveTab("list")}
            className={`px-6 py-2.5 rounded-lg text-sm font-bold uppercase transition-all ${
              activeTab === "list"
                ? "bg-red-600 text-white shadow-lg shadow-red-950"
                : "bg-neutral-900 text-neutral-400 hover:text-white"
            }`}
          >
            Hannover List
          </button>
        </div>

        <div className="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          <div className="space-y-4">
            <h3 className="text-2xl font-black uppercase text-white">
              Sports &amp; Spa {activeTab === "suedstadt" ? "Südstadt" : "List"}
            </h3>
            <div className="space-y-3 text-xs text-neutral-300">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <span>
                  {activeTab === "suedstadt"
                    ? "Hildesheimer Str. 42, 30169 Hannover"
                    : "Podbielskistraße 166, 30177 Hannover"}
                </span>
              </div>
              <div className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <div>
                  <p>Mo - Fr: 06:00 - 23:00 Uhr</p>
                  <p>Sa - So &amp; Feiertage: 08:00 - 22:00 Uhr</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <span>
                  {activeTab === "suedstadt"
                    ? "0511 / 807 420"
                    : "0511 / 696 800"}
                </span>
              </div>
            </div>
            <div className="pt-2 text-xs text-neutral-400">
              <p className="font-semibold text-white">
                Highlights an diesem Standort:
              </p>
              <ul className="list-disc list-inside mt-1 space-y-0.5 text-neutral-400">
                <li>Wellnessbereich mit Kaminlounge &amp; Sauna</li>
                {activeTab === "suedstadt" && (
                  <li>Außenbecken &amp; Freiluft-Entspannung</li>
                )}
                <li>Ladies Only Area (Pink Zone)</li>
                <li>Großer Functional Training Court</li>
              </ul>
            </div>
          </div>

          <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-center space-y-3">
            <div className="text-red-500 text-3xl font-black">0,00 €</div>
            <p className="text-xs text-neutral-300 uppercase font-bold">
              Die ersten 3 Monate gratis trainieren
            </p>
            <p className="text-[11px] text-neutral-500 leading-normal">
              Gilt für beide Standorte in Hannover. Sichere dir deinen Platz
              online und spare zusätzlich 50€ Aufnahmegebühr!
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
