import React, { useState, useEffect } from "react";
import { getConsent, setConsent } from "@/lib/pixel";

// Consent-Banner im Design-System: keine runden Ecken, Akzent-Rot.
// Pixel läuft erst nach Zustimmung.
export const ConsentBanner: React.FC = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(getConsent() === null);
  }, []);

  if (!visible) return null;

  const accept = () => {
    setConsent("granted");
    setVisible(false);
  };

  const deny = () => {
    setConsent("denied");
    setVisible(false);
  };

  return (
    <div className="fixed bottom-0 inset-x-0 z-[100] px-4 pb-4 sm:pb-6">
      <div className="mx-auto max-w-3xl bg-[#FBF9F5] border border-[#C9BFB0] shadow-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center gap-4">
        <p className="text-xs sm:text-sm text-[#4A443E] leading-relaxed flex-1">
          Wir nutzen Tracking-Pixel (Meta), um den Erfolg unseres Angebots zu
          messen. Mit Klick auf „Zustimmen" erlaubst du das Laden. Details in
          unserer{" "}
          <a
            href="https://www.sportsundspa.de"
            target="_blank"
            rel="noopener noreferrer"
            className="underline font-semibold text-[#C8102E]"
          >
            Datenschutzerklärung
          </a>
          .
        </p>
        <div className="flex gap-2 shrink-0">
          <button
            onClick={deny}
            className="h-11 px-4 text-xs font-semibold uppercase tracking-wider text-[#4A443E] border border-[#C9BFB0] hover:bg-[#F1ECE3] transition-colors"
          >
            Ablehnen
          </button>
          <button
            onClick={accept}
            className="h-11 px-5 text-xs font-bold uppercase tracking-wider text-white bg-[#C8102E] hover:bg-[#a50d26] transition-colors"
          >
            Zustimmen
          </button>
        </div>
      </div>
    </div>
  );
};
