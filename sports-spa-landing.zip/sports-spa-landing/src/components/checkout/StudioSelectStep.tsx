import React from "react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { IMAGES } from "@/lib/constants";
import { type StudioKey } from "@/lib/studio";

interface Props {
  studioKey: StudioKey;
  setStudioKey: (k: StudioKey) => void;
  onContinue: () => void;
}

export const StudioSelectStep: React.FC<Props> = ({
  studioKey,
  setStudioKey,
  onContinue,
}) => (
  <div className="bg-[#0f0408] text-white p-8 sm:p-10 text-center space-y-6">
    <div className="flex justify-center">
      <img
        src={IMAGES.LOGO_WHITE}
        alt="Sports & Spa"
        className="h-6 object-contain"
      />
    </div>

    <div className="bg-[#180a0f] border border-neutral-800 p-6 rounded-xl space-y-5">
      <h2 className="text-2xl font-black tracking-wider uppercase text-white">
        DEIN STUDIO
      </h2>

      <Select
        value={studioKey}
        onValueChange={(v) => setStudioKey(v as StudioKey)}
      >
        <SelectTrigger className="w-full bg-[#241219] border border-pink-500/50 text-neutral-200 h-11 rounded-md text-sm">
          <SelectValue placeholder="Bitte wähle Dein gewünschtes Studio" />
        </SelectTrigger>
        <SelectContent className="bg-[#241219] text-white border-neutral-700">
          <SelectItem value="suedstadt">Hannover Südstadt</SelectItem>
          <SelectItem value="list">Hannover List</SelectItem>
        </SelectContent>
      </Select>

      <Button
        onClick={onContinue}
        className="bg-[#8c1d24] hover:bg-[#73151b] text-white font-bold py-2.5 px-8 text-xs uppercase tracking-widest rounded"
      >
        WEITER
      </Button>
    </div>
  </div>
);
