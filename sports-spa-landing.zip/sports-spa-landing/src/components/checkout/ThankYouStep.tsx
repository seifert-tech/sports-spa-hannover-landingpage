import React from "react";
import { Button } from "@/components/ui/button";
import { IMAGES } from "@/lib/constants";

interface Props {
  onContinue: () => void;
}

export const ThankYouStep: React.FC<Props> = ({ onContinue }) => (
  <div className="bg-[#0b0305] text-white p-6 sm:p-8 space-y-6">
    <div className="flex justify-center">
      <img
        src={IMAGES.LOGO_WHITE}
        alt="Sports & Spa"
        className="h-6 object-contain"
      />
    </div>

    <div className="text-center space-y-3">
      <h2 className="text-3xl font-black uppercase text-white tracking-wide">
        VIELEN DANK!
      </h2>
      <p className="text-xs sm:text-sm text-neutral-300">
        Wir haben dir dein Angebot für 24 Stunden reserviert!
      </p>
      <p className="text-xs text-neutral-400">
        Klicke jetzt auf den Button und melde dich ganz einfach Online an.
      </p>
      <p className="text-xs text-red-400 font-bold italic">
        Du sparst bei einer Online-Anmeldung die Aufnahmegebühr in Höhe von 50€!
      </p>
    </div>

    <div className="flex justify-center gap-4 text-center py-2 border-y border-neutral-800">
      <div>
        <div className="text-2xl font-black">00</div>
        <div className="text-[10px] text-neutral-500 uppercase">Tage</div>
      </div>
      <div className="text-xl font-bold text-neutral-600">:</div>
      <div>
        <div className="text-2xl font-black text-red-500">23</div>
        <div className="text-[10px] text-neutral-500 uppercase">Stunden</div>
      </div>
      <div className="text-xl font-bold text-neutral-600">:</div>
      <div>
        <div className="text-2xl font-black text-red-500">59</div>
        <div className="text-[10px] text-neutral-500 uppercase">Minuten</div>
      </div>
      <div className="text-xl font-bold text-neutral-600">:</div>
      <div>
        <div className="text-2xl font-black text-red-500">45</div>
        <div className="text-[10px] text-neutral-500 uppercase">Sekunden</div>
      </div>
    </div>

    <Button
      onClick={onContinue}
      className="w-full bg-[#8c1d24] hover:bg-[#73151b] text-white font-black py-6 text-sm uppercase rounded-md shadow-lg tracking-wider"
    >
      <div className="flex flex-col items-center">
        <span>ANGEBOT SICHERN</span>
        <span className="text-[10px] font-normal text-red-200">
          & Aufnahmegebühr sparen
        </span>
      </div>
    </Button>
  </div>
);
