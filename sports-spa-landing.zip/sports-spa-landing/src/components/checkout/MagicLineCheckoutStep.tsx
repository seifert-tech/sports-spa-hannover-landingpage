import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { IMAGES } from "@/lib/constants";
import { Loader2 } from "lucide-react";
import {
  STUDIOS,
  type StudioKey,
  type StudioConfig,
  getKennung,
  sendAbschlussWebhook,
  createMagicLineContract,
} from "@/lib/studio";
import { trackPixel } from "@/lib/pixel";

type Gender = "MALE" | "FEMALE" | "DIVERSE";

interface Props {
  studioKey: StudioKey;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  accountHolder: string;
  setAccountHolder: (v: string) => void;
  onBack: () => void;
  onSuccess: () => void;
}

export const MagicLineCheckoutStep: React.FC<Props> = (props) => {
  const {
    studioKey,
    firstName,
    lastName,
    email,
    phone,
    accountHolder,
    setAccountHolder,
    onBack,
    onSuccess,
  } = props;

  const studio: StudioConfig = STUDIOS[studioKey];
  const kennung = getKennung();

  const [gender, setGender] = useState<Gender>("MALE");
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [street, setStreet] = useState("");
  const [houseNumber, setHouseNumber] = useState("");
  const [zipCode, setZipCode] = useState("");
  const [city, setCity] = useState("");
  const [iban, setIban] = useState("");
  const [phoneVal, setPhoneVal] = useState(phone);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    const result = await createMagicLineContract(studio, {
      gender,
      firstName,
      lastName,
      dateOfBirth,
      email,
      street,
      houseNumber,
      zipCode,
      city,
      iban,
      accountHolder,
      phone: phoneVal,
    });

    if (!result.ok) {
      setIsSubmitting(false);
      setError(
        result.error ||
          "Abschluss fehlgeschlagen. Bitte versuche es erneut oder kontaktiere uns.",
      );
      return;
    }

    sendAbschlussWebhook(studio, {
      firstName,
      lastName,
      email,
      phone: phoneVal,
      kennung,
    });

    // Meta Pixel — Purchase (nur nach bestätigtem Abschluss, ohne value)
    trackPixel("Purchase", { content_name: "3 Monate Gratis Vertrag" });

    setIsSubmitting(false);
    onSuccess();
  };

  return (
    <div className="bg-[#100508] text-white p-6 space-y-4">
      <div className="flex justify-center">
        <img
          src={IMAGES.LOGO_WHITE}
          alt="Sports & Spa"
          className="h-5 object-contain"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
        <div className="bg-[#1a0b10] border border-neutral-800 p-4 rounded-lg space-y-1">
          <span className="bg-[#8c1d24] text-white text-[9px] font-bold px-1.5 py-0.5 rounded">
            24 MONATE
          </span>
          <p className="font-bold text-white text-xs pt-1">3 Monate GRATIS</p>
          <div className="text-2xl font-black text-white">
            0,00€<span className="text-[10px] font-normal">/4-wtl.*</span>
          </div>
          <p className="text-[10px] text-neutral-400">
            Gewählt: {studio.label}
          </p>
        </div>
        <div className="bg-[#1a0b10] border border-neutral-800 p-4 rounded-lg space-y-1 text-neutral-300 text-[11px]">
          <p className="text-emerald-400 font-semibold">✓ Fitness & Wellness</p>
          <p className="text-emerald-400 font-semibold">
            ✓ Classes & EmJay's WOD
          </p>
          <p className="text-emerald-400 font-semibold">✓ Trainer Workshops</p>
        </div>
      </div>

      <form
        onSubmit={handleSubmit}
        className="bg-white text-neutral-900 p-5 rounded-lg space-y-3"
      >
        <h3 className="text-sm font-bold border-b pb-2">Deine Kontaktdaten</h3>

        <div className="grid grid-cols-3 gap-2">
          <div>
            <Label className="text-[11px]">Anrede*</Label>
            <Select
              value={gender}
              onValueChange={(v) => setGender(v as Gender)}
            >
              <SelectTrigger className="bg-neutral-50 h-9 text-xs mt-0.5">
                <SelectValue placeholder="Anrede" />
              </SelectTrigger>
              <SelectContent className="bg-white text-neutral-900">
                <SelectItem value="MALE">Herr</SelectItem>
                <SelectItem value="FEMALE">Frau</SelectItem>
                <SelectItem value="DIVERSE">Divers</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-[11px]">Vorname*</Label>
            <Input
              required
              placeholder="Vorname"
              value={firstName}
              readOnly
              className="bg-neutral-100 h-9 text-xs mt-0.5"
            />
          </div>
          <div>
            <Label className="text-[11px]">Nachname*</Label>
            <Input
              required
              placeholder="Nachname"
              value={lastName}
              readOnly
              className="bg-neutral-100 h-9 text-xs mt-0.5"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label className="text-[11px]">Geburtsdatum*</Label>
            <Input
              required
              type="date"
              value={dateOfBirth}
              onChange={(e) => setDateOfBirth(e.target.value)}
              className="bg-neutral-50 h-9 text-xs mt-0.5"
            />
          </div>
          <div>
            <Label className="text-[11px]">Telefon*</Label>
            <Input
              required
              type="tel"
              placeholder="Telefon"
              value={phoneVal}
              onChange={(e) => setPhoneVal(e.target.value)}
              className="bg-neutral-50 h-9 text-xs mt-0.5"
            />
          </div>
        </div>

        <div>
          <Label className="text-[11px]">E-Mail*</Label>
          <Input
            required
            type="email"
            placeholder="E-Mail"
            value={email}
            readOnly
            className="bg-neutral-100 h-9 text-xs mt-0.5"
          />
        </div>

        <div className="grid grid-cols-[1fr_70px] gap-2">
          <div>
            <Label className="text-[11px]">Straße*</Label>
            <Input
              required
              placeholder="Straße"
              value={street}
              onChange={(e) => setStreet(e.target.value)}
              className="bg-neutral-50 h-9 text-xs mt-0.5"
            />
          </div>
          <div>
            <Label className="text-[11px]">Nr.*</Label>
            <Input
              required
              placeholder="Nr."
              value={houseNumber}
              onChange={(e) => setHouseNumber(e.target.value)}
              className="bg-neutral-50 h-9 text-xs mt-0.5"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label className="text-[11px]">PLZ*</Label>
            <Input
              required
              placeholder="PLZ"
              value={zipCode}
              onChange={(e) => setZipCode(e.target.value)}
              className="bg-neutral-50 h-9 text-xs mt-0.5"
            />
          </div>
          <div>
            <Label className="text-[11px]">Ort*</Label>
            <Input
              required
              placeholder="Ort"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="bg-neutral-50 h-9 text-xs mt-0.5"
            />
          </div>
        </div>

        <div>
          <Label className="text-[11px]">Kontoinhaber*</Label>
          <Input
            required
            placeholder="Vor- und Nachname"
            value={accountHolder}
            onChange={(e) => setAccountHolder(e.target.value)}
            className="bg-neutral-50 h-9 text-xs mt-0.5"
          />
        </div>

        <div>
          <Label className="text-[11px]">IBAN für SEPA-Lastschrift*</Label>
          <Input
            required
            placeholder="DE89 3704 0044 0532 0130 00"
            value={iban}
            onChange={(e) => setIban(e.target.value)}
            className="bg-neutral-50 h-9 font-mono text-xs mt-0.5"
          />
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 text-[11px] p-2 rounded">
            {error}
          </div>
        )}

        <div className="flex gap-2 pt-2">
          <Button
            type="button"
            onClick={onBack}
            className="w-1/2 bg-neutral-800 text-white font-bold h-10 text-xs"
          >
            ZURÜCK
          </Button>
          <Button
            type="submit"
            disabled={isSubmitting}
            className="w-1/2 bg-[#8c1d24] hover:bg-[#73151b] text-white font-bold h-10 text-xs uppercase"
          >
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <Loader2 className="w-3 h-3 animate-spin" /> BUCHUNG...
              </span>
            ) : (
              "VERTRAG ABSCHLIESSEN"
            )}
          </Button>
        </div>
        <p className="text-[9px] text-neutral-400 leading-tight">
          Mit dem Abschluss beauftragst du die Sports & Spa {studio.label} GmbH
          mit der Einrichtung deiner Mitgliedschaft (3 Monate gratis, danach
          59,99 €/4-wtl., 24 Monate Laufzeit). Aufnahmegebühr und erste
          SmartCard entfallen online.
        </p>
      </form>
    </div>
  );
};
