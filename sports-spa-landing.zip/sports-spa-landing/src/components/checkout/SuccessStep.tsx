import React from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";
import { STUDIOS, type StudioKey } from "@/lib/studio";

interface Props {
  studioKey: StudioKey;
  firstName: string;
  onClose: () => void;
}

export const SuccessStep: React.FC<Props> = ({
  studioKey,
  firstName,
  onClose,
}) => {
  const studio = STUDIOS[studioKey];
  return (
    <div className="bg-[#0f0408] text-white p-8 text-center space-y-4">
      <CheckCircle2 className="w-12 h-12 text-red-500 mx-auto" />
      <h3 className="text-xl font-bold uppercase">
        Vielen Dank, {firstName || "Mitglied"}!
      </h3>
      <p className="text-xs text-neutral-300">
        Deine Anmeldung für {studio.label} wurde erfolgreich über MagicLine
        angelegt und aktiviert. Deine Clubkarte kannst du im Studio abholen.
      </p>
      <p className="text-[11px] text-neutral-400">
        Nächste Schritte: Bestätigung per E-Mail · Clubkarte im Club abholen ·
        Persönliche Trainingseinweisung
      </p>
      <Button
        onClick={onClose}
        className="w-full bg-neutral-800 text-white font-bold uppercase h-10 text-xs"
      >
        Schließen
      </Button>
    </div>
  );
};
