import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { postTrackingEvent } from "@/lib/tracking";
import { trackPixel } from "@/lib/pixel";
import {
  STUDIOS,
  type StudioKey,
  type StudioConfig,
  getKennung,
  sendLeadWebhook,
  TAGS,
} from "@/lib/studio";

interface LeadStepProps {
  studioKey: StudioKey;
  setStudioKey: (k: StudioKey) => void;
  fullName: string;
  setFullName: (v: string) => void;
  firstName: string;
  setFirstName: (v: string) => void;
  lastName: string;
  setLastName: (v: string) => void;
  email: string;
  setEmail: (v: string) => void;
  phone: string;
  setPhone: (v: string) => void;
  setAccountHolder: (v: string) => void;
  onDone: () => void;
}

export const LeadStep: React.FC<LeadStepProps> = (props) => {
  const {
    studioKey,
    setStudioKey,
    fullName,
    setFullName,
    setFirstName,
    setLastName,
    email,
    setEmail,
    phone,
    setPhone,
    setAccountHolder,
    onDone,
  } = props;

  const [privacyAgreed, setPrivacyAgreed] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const studio: StudioConfig = STUDIOS[studioKey];
  const kennung = getKennung();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!privacyAgreed) return;

    setIsSubmitting(true);

    const parts = fullName.trim().split(" ");
    const fname = parts[0] || "";
    const lname = parts.slice(1).join(" ") || "";
    setFirstName(fname);
    setLastName(lname);
    setAccountHolder(`${fname} ${lname}`.trim());

    // 1) GHL-Webhook in den richtigen Sub-Account (einzelner Lead-Tag)
    sendLeadWebhook(studio, {
      firstName: fname,
      lastName: lname,
      email,
      phone,
      kennung,
    });

    // 2) Meta Pixel — Lead Event
    trackPixel("Lead", { content_name: "3 Monate Gratis Angebot" });

    // 3) Tracking-Event
    postTrackingEvent(
      {
        type: "external form_submission",
        timestamp: Date.now(),
        formId: "sports-spa-lead-offer",
        tags: [TAGS.lead],
        formData: { first_name: fname, last_name: lname, email, phone },
        formLabels: {
          first_name: "Vorname",
          last_name: "Nachname",
          email: "E-Mail-Adresse",
          phone: "Telefonnummer",
        },
        url: window.location.href,
        title: document.title,
        path: window.location.pathname,
        userAgent: navigator.userAgent,
        trackingId: "tk_fce89262165240a693b0221d1691db40",
        locationId: studio.locationId,
        projectId: "1788272212629402141",
        sessionId: crypto.randomUUID(),
        properties: {
          deviceType: /Mobile|Android|iPhone/i.test(navigator.userAgent)
            ? "mobile"
            : "desktop",
          source: "ai_studio",
          projectId: "1788272212629402141",
          formName: "3 Monate Gratis Angebot Lead-Formular",
        },
      },
      {
        customFields: {
          "6OrYIMY66wjfsXKgV8OM": {
            value: studio.label,
            label: "Wunschstudio",
          },
        },
      },
    );

    setTimeout(() => {
      setIsSubmitting(false);
      onDone();
    }, 600);
  };

  return (
    <div className="bg-white text-neutral-900 p-6 sm:p-8 space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-2xl sm:text-3xl font-black text-neutral-900 leading-tight">
          Gerne reservieren wir dir dein Angebot!
        </h2>
        <p className="text-neutral-500 text-xs sm:text-sm leading-relaxed max-w-md mx-auto">
          Trage dich hier ein und wir reservieren dir völlig unverbindlich dein
          Angebot. Du kannst es danach ganz entspannt in 2 Minuten online
          abschließen.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Select
            value={studioKey}
            onValueChange={(v) => setStudioKey(v as StudioKey)}
          >
            <SelectTrigger className="w-full bg-neutral-50 border-neutral-200 text-neutral-800 text-sm h-12 rounded-md">
              <SelectValue placeholder="Wähle deinen Standort *" />
            </SelectTrigger>
            <SelectContent className="bg-white text-neutral-900 border-neutral-200">
              <SelectItem value="suedstadt">Hannover Südstadt</SelectItem>
              <SelectItem value="list">Hannover List</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Input
          required
          placeholder="Vollständiger Name *"
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          className="bg-neutral-50 border-neutral-200 text-neutral-900 placeholder:text-neutral-400 h-12 text-sm rounded-md"
        />
        <Input
          type="email"
          required
          placeholder="E-mail *"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="bg-neutral-50 border-neutral-200 text-neutral-900 placeholder:text-neutral-400 h-12 text-sm rounded-md"
        />
        <Input
          type="tel"
          required
          placeholder="Telefon *"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          className="bg-neutral-50 border-neutral-200 text-neutral-900 placeholder:text-neutral-400 h-12 text-sm rounded-md"
        />

        <div className="bg-neutral-100 p-3 rounded-md flex items-center gap-3">
          <Checkbox
            id="privacy"
            checked={privacyAgreed}
            onCheckedChange={(checked) => setPrivacyAgreed(!!checked)}
            className="border-neutral-400 data-[state=checked]:bg-[#600810] data-[state=checked]:border-[#600810]"
          />
          <Label
            htmlFor="privacy"
            className="text-xs text-neutral-700 leading-tight font-normal"
          >
            Ich akzeptiere die{" "}
            <span className="underline font-semibold">
              Datenschutzerklärung
            </span>{" "}
            *
          </Label>
        </div>

        <Button
          type="submit"
          disabled={!privacyAgreed || isSubmitting}
          className="w-full bg-[#600810] hover:bg-[#4a060c] text-white font-bold h-12 rounded-md uppercase tracking-wider text-sm transition-all"
        >
          {isSubmitting ? "WEITER..." : "WEITER"}
        </Button>
      </form>
    </div>
  );
};
