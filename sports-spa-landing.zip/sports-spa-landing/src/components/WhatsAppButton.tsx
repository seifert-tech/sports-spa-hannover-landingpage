import React, { useState } from "react";
import { STUDIOS, whatsappLink, type StudioKey } from "@/lib/studio";

interface WhatsAppButtonProps {
  variant?: "hero" | "compact";
  className?: string;
}

/**
 * „Noch Fragen?"-Button mit WhatsApp-Anbindung.
 * Da im Hero noch kein Studio gewählt ist, öffnet er ein kleines Auswahl-Menü
 * (List / Südstadt) und leitet dann zur passenden WhatsApp-Nummer weiter.
 */
export const WhatsAppButton: React.FC<WhatsAppButtonProps> = ({
  variant = "hero",
  className = "",
}) => {
  const [open, setOpen] = useState(false);

  const openChat = (key: StudioKey) => {
    window.open(whatsappLink(STUDIOS[key]), "_blank", "noopener,noreferrer");
    setOpen(false);
  };

  const base =
    variant === "hero"
      ? "w-full bg-transparent border border-white/30 hover:bg-white/10 text-white font-bold text-xs sm:text-sm uppercase tracking-wider py-3 px-6 rounded-xl flex items-center justify-center gap-2 transition-all"
      : "w-full bg-emerald-600/90 hover:bg-emerald-600 text-white font-bold text-[11px] uppercase tracking-wider py-2.5 px-4 rounded-lg flex items-center justify-center gap-2 transition-all";

  return (
    <div className={`relative ${className}`}>
      <button onClick={() => setOpen((v) => !v)} className={base}>
        <WhatsAppIcon className="w-4 h-4" />
        Noch Fragen? WhatsApp
      </button>

      {open && (
        <>
          {/* Klick außerhalb schließt */}
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute bottom-full mb-2 left-0 right-0 z-50 bg-neutral-900 border border-neutral-700 rounded-xl overflow-hidden shadow-2xl">
            <p className="text-[10px] uppercase tracking-widest text-neutral-400 px-4 pt-3 pb-1">
              Wähle dein Studio
            </p>
            {(Object.keys(STUDIOS) as StudioKey[]).map((key) => (
              <button
                key={key}
                onClick={() => openChat(key)}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-neutral-800 transition-colors text-left"
              >
                <WhatsAppIcon className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="text-sm font-semibold text-white">
                  {STUDIOS[key].label}
                </span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

const WhatsAppIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="currentColor"
    aria-hidden="true"
  >
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
  </svg>
);
