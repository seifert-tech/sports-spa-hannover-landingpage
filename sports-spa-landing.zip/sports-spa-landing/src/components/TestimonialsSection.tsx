import React from "react";
import { Button } from "@/components/ui/button";
import { Star } from "lucide-react";

interface TestimonialsSectionProps {
  onOpenModal: () => void;
}

export const TestimonialsSection: React.FC<TestimonialsSectionProps> = ({
  onOpenModal,
}) => {
  return (
    <section className="py-16 px-4 bg-neutral-950 border-t border-neutral-900">
      <div className="max-w-6xl mx-auto space-y-12">
        <div className="text-center space-y-2">
          <p className="text-xs font-bold text-red-500 italic uppercase tracking-widest">
            DAS SAGEN
          </p>
          <h2 className="text-3xl sm:text-4xl font-black uppercase text-white">
            UNSERE MITGLEIDER
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-6 space-y-4 text-center flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex justify-center text-amber-500 gap-1">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-500" />
                ))}
              </div>
              <h4 className="font-extrabold text-white text-lg">
                Tolle Atmosphäre!
              </h4>
              <p className="text-neutral-400 text-xs leading-relaxed">
                "Hier stimmt für mich absolut alles. Alles ist sehr sauber und
                die Geräte sind hochwertig. Die Trainer sind stets super
                gelaunt, nehmen sich Zeit bei Fragen und geben Tipps fürs
                Training. Ein richtig familiärer Fitness‒Club, in dem es viel
                Spaß macht zu trainieren."
              </p>
            </div>
            <div className="pt-4 border-t border-neutral-800">
              <p className="font-bold text-white text-sm">Anja M.</p>
              <p className="text-[11px] text-neutral-500">
                Mitglied in Hannover Südstadt
              </p>
            </div>
          </div>

          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-6 space-y-4 text-center flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex justify-center text-amber-500 gap-1">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-500" />
                ))}
              </div>
              <h4 className="font-extrabold text-white text-lg">
                Super Studio!
              </h4>
              <p className="text-neutral-400 text-xs leading-relaxed">
                "Einfach ein tolles Studio! Alle Mitarbeiter sind nett und
                zuvorkommend. Das Studio hat alles was man braucht und ist
                dementsprechend bestens ausgestattet. Ich kann das Fitnessstudio
                nur weiter empfehlen."
              </p>
            </div>
            <div className="pt-4 border-t border-neutral-800">
              <p className="font-bold text-white text-sm">Laura K.</p>
              <p className="text-[11px] text-neutral-500">
                Mitglied in Hannover List
              </p>
            </div>
          </div>

          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-6 space-y-4 text-center flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex justify-center text-amber-500 gap-1">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-500" />
                ))}
              </div>
              <h4 className="font-extrabold text-white text-lg">
                Top ausgestattet 🚀
              </h4>
              <p className="text-neutral-400 text-xs leading-relaxed">
                "Ich bin bereits langjähriger Kunde und ein großer Fan des
                Sports &amp; Spa. Insbesondere nach dem Umzug in die neuen
                Räumlichkeiten hat das Studio noch mal einen gewaltigen Sprung
                nach vorne gemacht. Das Gym ist absolut gepflegt und hat alles
                was man braucht."
              </p>
            </div>
            <div className="pt-4 border-t border-neutral-800">
              <p className="font-bold text-white text-sm">Aleks M.</p>
              <p className="text-[11px] text-neutral-500">
                Langjähriges Mitglied
              </p>
            </div>
          </div>
        </div>

        <div className="text-center pt-4">
          <Button
            onClick={onOpenModal}
            className="bg-red-600 hover:bg-red-700 text-white font-black py-6 px-10 uppercase tracking-wider text-sm rounded-xl animate-pulse-glow"
          >
            ANGEBOT SICHERN
          </Button>
        </div>
      </div>
    </section>
  );
};
