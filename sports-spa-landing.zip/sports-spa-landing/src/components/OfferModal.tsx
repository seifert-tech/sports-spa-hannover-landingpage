import React, { useState, useEffect } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import {
  type StudioKey,
  getStudioFromUrl,
  getPrefillFromUrl,
} from "@/lib/studio";
import { LeadStep } from "@/components/checkout/LeadStep";
import { ThankYouStep } from "@/components/checkout/ThankYouStep";
import { StudioSelectStep } from "@/components/checkout/StudioSelectStep";
import { MagicLineCheckoutStep } from "@/components/checkout/MagicLineCheckoutStep";
import { SuccessStep } from "@/components/checkout/SuccessStep";

interface OfferModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type Step =
  "lead" | "thank_you" | "studio_select" | "magicline_checkout" | "success";

export const OfferModal: React.FC<OfferModalProps> = ({ isOpen, onClose }) => {
  const [step, setStep] = useState<Step>("lead");

  const [fullName, setFullName] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [studioKey, setStudioKey] = useState<StudioKey>("suedstadt");
  const [accountHolder, setAccountHolder] = useState("");

  // URL-Prefill & Direkt-Abschluss-Sprung
  useEffect(() => {
    if (!isOpen) return;
    const prefill = getPrefillFromUrl();
    const urlStudio = getStudioFromUrl();
    if (urlStudio) setStudioKey(urlStudio);
    if (prefill.firstName) setFirstName(prefill.firstName);
    if (prefill.lastName) setLastName(prefill.lastName);
    if (prefill.firstName || prefill.lastName)
      setFullName(`${prefill.firstName} ${prefill.lastName}`.trim());
    if (prefill.email) setEmail(prefill.email);
    if (prefill.phone) setPhone(prefill.phone);
    if (prefill.directAbschluss) setStep("studio_select");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);

  const resetAndClose = () => {
    onClose();
    setTimeout(() => setStep("lead"), 300);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && resetAndClose()}>
      <DialogContent className="sm:max-w-[540px] max-h-[90vh] overflow-y-auto bg-neutral-950 text-white border-neutral-800 p-0 rounded-xl shadow-2xl">
        {step === "lead" && (
          <LeadStep
            studioKey={studioKey}
            setStudioKey={setStudioKey}
            fullName={fullName}
            setFullName={setFullName}
            firstName={firstName}
            setFirstName={setFirstName}
            lastName={lastName}
            setLastName={setLastName}
            email={email}
            setEmail={setEmail}
            phone={phone}
            setPhone={setPhone}
            setAccountHolder={setAccountHolder}
            onDone={() => setStep("thank_you")}
          />
        )}

        {step === "thank_you" && (
          <ThankYouStep onContinue={() => setStep("studio_select")} />
        )}

        {step === "studio_select" && (
          <StudioSelectStep
            studioKey={studioKey}
            setStudioKey={setStudioKey}
            onContinue={() => setStep("magicline_checkout")}
          />
        )}

        {step === "magicline_checkout" && (
          <MagicLineCheckoutStep
            studioKey={studioKey}
            firstName={firstName}
            lastName={lastName}
            email={email}
            phone={phone}
            accountHolder={accountHolder}
            setAccountHolder={setAccountHolder}
            onBack={() => setStep("studio_select")}
            onSuccess={() => setStep("success")}
          />
        )}

        {step === "success" && (
          <SuccessStep
            studioKey={studioKey}
            firstName={firstName}
            onClose={resetAndClose}
          />
        )}
      </DialogContent>
    </Dialog>
  );
};
