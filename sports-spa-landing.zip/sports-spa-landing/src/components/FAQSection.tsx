import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";

interface FAQSectionProps {
  onOpenModal: () => void;
}

export const FAQSection: React.FC<FAQSectionProps> = ({ onOpenModal }) => {
  return (
    <section className="py-16 px-4 bg-neutral-950 border-y border-neutral-900">
      <div className="max-w-3xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <p className="text-xs font-bold text-red-500 italic uppercase tracking-widest">
            HÄUFIG
          </p>
          <h2 className="text-3xl sm:text-4xl font-black uppercase text-white">
            GESTELTE FRAGEN
          </h2>
        </div>

        <Accordion type="single" collapsible className="space-y-4">
          <AccordionItem
            value="item-1"
            className="border border-neutral-800 bg-neutral-900/80 rounded-xl px-4"
          >
            <AccordionTrigger className="text-left font-bold text-white text-base py-4 hover:no-underline">
              Wie läuft die Aktion ab?
            </AccordionTrigger>
            <AccordionContent className="text-neutral-400 text-sm leading-relaxed pb-4 space-y-2">
              <p>
                Sichere Dir jetzt unser streng limitiertes Frühjahrs-Angebot und
                trainiere <strong>3 Monate komplett gratis*</strong>!
              </p>
              <p>
                Ab dem 4. Monat trainierst du dann für{" "}
                <strong>59,99€/4wtl.</strong> weiter.
              </p>
              <p className="text-emerald-400 font-medium">
                Wenn du dich online anmeldest, sparst du sogar die
                Aufnahmegebühr in Höhe von 50,00€!
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem
            value="item-2"
            className="border border-neutral-800 bg-neutral-900/80 rounded-xl px-4"
          >
            <AccordionTrigger className="text-left font-bold text-white text-base py-4 hover:no-underline">
              Welche Workout Highlights gibt es?
            </AccordionTrigger>
            <AccordionContent className="text-neutral-400 text-sm leading-relaxed pb-4 space-y-2">
              <p>
                Egal, ob Zirkeltraining, Cardio, EmJay&apos;s Workout Box oder
                der Functional Court - für jeden ist etwas dabei, auch für die
                Ladies!
              </p>
              <p>
                In der Pink Area findest du spezielle Trainingsgeräte, die auf
                die Bedürfnisse der Frauen zugeschnitten sind.
              </p>
              <p>
                Zusätzlich bieten wir vielfältige Kurse wie Pilates, Yoga und
                Cycling an. Also worauf wartest du noch? Melde dich jetzt an und
                starte direkt mit deinem Training.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem
            value="item-3"
            className="border border-neutral-800 bg-neutral-900/80 rounded-xl px-4"
          >
            <AccordionTrigger className="text-left font-bold text-white text-base py-4 hover:no-underline">
              Was kann ich im Wellnessbereich nutzen?
            </AccordionTrigger>
            <AccordionContent className="text-neutral-400 text-sm leading-relaxed pb-4 space-y-2">
              <p>
                Entdecke in unserem Wellnessbereich eine einladende Kaminlounge,
                perfekt für gemütliche Momente und gesellige Gespräche.
              </p>
              <p>
                Ruhe und Entspannung erwarten dich auch in unserer Flüsterzone,
                ideal für deine persönliche Auszeit. Und natürlich darf eine
                Sauna nicht fehlen, um Körper und Geist zu entspannen.
              </p>
              <p>
                In Hannover List und Hannover Südstadt bieten wir separate
                Saunabereiche für Frauen und Männer an.
              </p>
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        <div className="text-center pt-4">
          <Button
            onClick={onOpenModal}
            className="bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-8 uppercase tracking-wider text-sm rounded-lg"
          >
            ANGEBOT SICHERN
          </Button>
        </div>
      </div>
    </section>
  );
};
