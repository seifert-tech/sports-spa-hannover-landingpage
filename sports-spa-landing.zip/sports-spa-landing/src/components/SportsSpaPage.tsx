import React, { useState, useEffect } from "react";
import { Header } from "@/components/Header";
import { HeroSection } from "@/components/HeroSection";
import { FeaturesGrid } from "@/components/FeaturesGrid";
import { DealSection } from "@/components/DealSection";
import { LocationsSection } from "@/components/LocationsSection";
import { TestimonialsSection } from "@/components/TestimonialsSection";
import { FAQSection } from "@/components/FAQSection";
import { Footer } from "@/components/Footer";
import { StickyCTA } from "@/components/StickyCTA";
import { OfferModal } from "@/components/OfferModal";
import { ConsentBanner } from "@/components/ConsentBanner";
import { initPixel } from "@/lib/pixel";

export const SportsSpaPage = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Pixel initialisieren (lädt nur, wenn Consent vorhanden)
  useEffect(() => {
    initPixel();
  }, []);

  // InitiateCheckout feuern, sobald das Angebot-Modal geöffnet wird
  useEffect(() => {
    if (isModalOpen) {
      import("@/lib/pixel").then(({ trackPixel }) =>
        trackPixel("InitiateCheckout"),
      );
    }
  }, [isModalOpen]);

  // Countdown timer logic
  const [timeLeft, setTimeLeft] = useState({
    days: "05",
    hours: "13",
    minutes: "42",
    seconds: "00",
  });

  useEffect(() => {
    const target =
      Date.now() + 5 * 24 * 3600 * 1000 + 13 * 3600 * 1000 + 42 * 60 * 1000;

    const interval = setInterval(() => {
      const now = Date.now();
      const diff = Math.max(0, target - now);

      const d = Math.floor(diff / (1000 * 60 * 60 * 24));
      const h = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const m = Math.floor((diff / 1000 / 60) % 60);
      const s = Math.floor((diff / 1000) % 60);

      setTimeLeft({
        days: String(d).padStart(2, "0"),
        hours: String(h).padStart(2, "0"),
        minutes: String(m).padStart(2, "0"),
        seconds: String(s).padStart(2, "0"),
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#080808] text-white font-sans selection:bg-red-600 selection:text-white pb-28 sm:pb-0">
      <HeroSection
        timeLeft={timeLeft}
        onOpenModal={() => setIsModalOpen(true)}
      />
      <Header onOpenModal={() => setIsModalOpen(true)} />
      <FeaturesGrid />
      <DealSection onOpenModal={() => setIsModalOpen(true)} />
      <LocationsSection />
      <TestimonialsSection onOpenModal={() => setIsModalOpen(true)} />
      <FAQSection onOpenModal={() => setIsModalOpen(true)} />
      <Footer />
      <StickyCTA onOpenModal={() => setIsModalOpen(true)} />

      <OfferModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      <ConsentBanner />
    </div>
  );
};
