import React from "react";
import { Button } from "@/components/ui/button";
import { IMAGES } from "@/lib/constants";

interface HeaderProps {
  onOpenModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenModal }) => {
  return (
    <header className="sticky top-0 z-30 bg-neutral-950/90 backdrop-blur-md border-b border-neutral-900 py-2 px-3 sm:py-3 sm:px-4">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-2">
        <img
          src={IMAGES.LOGO_WHITE}
          alt="Sports & Spa Hannover"
          className="h-6 sm:h-9 object-contain"
        />
        <Button
          onClick={onOpenModal}
          className="bg-red-600 hover:bg-red-700 text-white font-bold text-[11px] sm:text-sm uppercase tracking-wider px-3 sm:px-4 py-2 shrink-0"
        >
          Angebot Sichern
        </Button>
      </div>
    </header>
  );
};
