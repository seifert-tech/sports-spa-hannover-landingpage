// Meta Pixel (Trinity) — consent-gated
// Pixel wird erst nach Zustimmung geladen. Events mit eventID zur Deduplizierung.
// Purchase nur nach bestätigtem Abschluss, ohne value.

export const META_PIXEL_ID = "1685429088954083";

const CONSENT_KEY = "ss_consent";

type ConsentState = "granted" | "denied" | null;

export function getConsent(): ConsentState {
  if (typeof window === "undefined") return null;
  return (localStorage.getItem(CONSENT_KEY) as ConsentState) || null;
}

export function setConsent(state: Exclude<ConsentState, null>) {
  if (typeof window === "undefined") return;
  localStorage.setItem(CONSENT_KEY, state);
  window.dispatchEvent(new CustomEvent("ss-consent-change", { detail: state }));
  if (state === "granted") loadPixel();
}

// Lädt das Pixel-Base-Code-Snippet und feuert PageView.
function loadPixel() {
  if (typeof window === "undefined") return;
  if ((window as any).fbq) return; // schon geladen

  /* eslint-disable */
  (function (f: any, b: any, e: any, v: any, n?: any, t?: any, s?: any) {
    if (f.fbq) return;
    n = f.fbq = function () {
      n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);
    };
    if (!f._fbq) f._fbq = n;
    n.push = n;
    n.loaded = true;
    n.version = "2.0";
    n.queue = [];
    t = b.createElement(e);
    t.async = true;
    t.src = v;
    s = b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t, s);
  })(
    window,
    document,
    "script",
    "https://connect.facebook.net/en_US/fbevents.js",
  );
  /* eslint-enable */

  (window as any).fbq("init", META_PIXEL_ID);
  (window as any).fbq(
    "track",
    "PageView",
    {},
    { eventID: eventId("pageview") },
  );
}

// Consent beim Start prüfen — falls schon früher erteilt, sofort laden.
export function initPixel() {
  if (getConsent() === "granted") loadPixel();
}

function eventId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

export type PixelEvent = "PageView" | "Lead" | "InitiateCheckout" | "Purchase";

export function trackPixel(
  event: PixelEvent,
  data: Record<string, unknown> = {},
) {
  if (typeof window === "undefined") return;
  if (getConsent() !== "granted") return; // nur nach Consent feuern
  const fbq = (window as any).fbq;
  if (!fbq) return;
  // Purchase ohne value (laut Referenz)
  const payload = event === "Purchase" ? {} : data;
  fbq("track", event, payload, { eventID: eventId(event.toLowerCase()) });
}
