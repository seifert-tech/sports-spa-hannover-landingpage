export const IMAGES = {
  LOGO_WHITE:
    "https://onecdn.io/media/65fc48e4-b0af-42ec-81bc-d1ff6b201fcd/md2x",
  LOGO_RED:
    "https://vibe.filesafe.space/1788272212629402141/attachments/15f29053-2681-4f25-af03-ba65c04076dc.png",
  HERO_BANNER:
    "https://vibe.filesafe.space/1788272212629402141/attachments/3a1dc9f5-4e18-483f-9e64-f0171e318993.png",
  HERO_BG: "https://onecdn.io/media/01e4f831-6a4b-4979-aca9-8f995312572c/xlg2x",
  HERO_MODEL:
    "https://vibe.filesafe.space/1788272212629402141/attachments/ac3f532b-13c5-4878-a632-5f58d125f9cf.png",
  ATHLETE_IMAGE:
    "https://vibe.filesafe.space/1788272212629402141/attachments/36a02444-2297-4bfb-8b0f-8a1fcc985bc1.jpg",
  THANK_YOU_BG:
    "https://vibe.filesafe.space/1788272212629402141/attachments/47bfe0a9-167f-404e-8344-c0e5e632157e.png",
};
