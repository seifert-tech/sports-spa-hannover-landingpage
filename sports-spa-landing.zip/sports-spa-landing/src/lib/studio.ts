// Sports & Spa · Studio-Konfiguration
// Beide Clubs haben eigene Sub-Accounts (Location-IDs) und Webhooks.
// Leads und Abschlüsse werden je nach gewähltem Studio in den richtigen Account geroutet.

export type StudioKey = "list" | "suedstadt";

export interface StudioConfig {
  key: StudioKey;
  label: string; // Anzeige
  city: string;
  address: string;
  studioId: string; // MagicLine studioId
  locationId: string; // Sub-Account Location-ID
  webhookBase: string; // https://services.leadconnectorhq.com/hooks/<locationId>/webhook-trigger
  leadTrigger: string; // Trigger-ID für Lead
  abschlussTrigger: string; // Trigger-ID für Abschluss
  rateBundleId: string; // 3 Monate GRATIS Tarif
  rateBundleTermId: string; // 24 Monate
  whatsapp: string; // WhatsApp-Nummer international ohne + (z. B. 495111234567)
}

export const STUDIOS: Record<StudioKey, StudioConfig> = {
  list: {
    key: "list",
    label: "Hannover List",
    city: "Hannover",
    address: "Lister Straße 7, im Podbi Park, 30163 Hannover",
    studioId: "1212004010",
    locationId: "G1Pv49X1vhT6FVlmmRKw",
    webhookBase:
      "https://services.leadconnectorhq.com/hooks/G1Pv49X1vhT6FVlmmRKw/webhook-trigger",
    leadTrigger: "ee3e0cb3-a3d9-429e-8cd7-31825085b1da",
    abschlussTrigger: "xgU8vfT9SpPnWiR6ySYw",
    rateBundleId: "1239177460",
    rateBundleTermId: "1239177490",
    whatsapp: "4915121201065",
  },
  suedstadt: {
    key: "suedstadt",
    label: "Hannover Südstadt",
    city: "Hannover",
    address: "Anna-Zammert-Straße 37, 30171 Hannover",
    studioId: "1210007760",
    locationId: "lLWlVZynp69uL7wFh1hx",
    webhookBase:
      "https://services.leadconnectorhq.com/hooks/lLWlVZynp69uL7wFh1hx/webhook-trigger",
    leadTrigger: "0abd7191-43b3-4d3f-acb2-aa4f203d4f50",
    abschlussTrigger: "8b3b4ad0-9a92-4ccc-b90a-77c0cdd516cb",
    rateBundleId: "1239177460",
    rateBundleTermId: "1239177490",
    whatsapp: "4915118563588",
  },
};

// WhatsApp-Link mit vorausgefüllter Nachricht
export function whatsappLink(studio: StudioConfig, message?: string): string {
  const text =
    message ?? "Hallo! Ich habe Fragen zum Angebot 3 Monate GRATIS trainieren.";
  return `https://wa.me/${studio.whatsapp}?text=${encodeURIComponent(text)}`;
}

// Tags – je einer pro Ereignis. Die Workflows im Sub-Account taggen weiter
// (magicline_member, in-widerrufsfrist, WA-DND …), die Landingpage feuert nur den Lead- bzw. Abschluss-Tag.
export const TAGS = {
  lead: "lead-landingpage-3monate",
  abschluss: "abschluss-online",
} as const;

// Kennung aus URL-Parametern (Quelle messen, nicht erfragen)
export function getKennung(): string {
  if (typeof window === "undefined") return "";
  const params = new URLSearchParams(window.location.search);
  return (
    params.get("k") ||
    params.get("ref") ||
    params.get("utm_content") ||
    params.get("utm_source") ||
    params.get("utm_campaign") ||
    params.get("fbclid") ||
    ""
  );
}

// Studio aus URL vorbefüllen (?studio=list | suedstadt)
export function getStudioFromUrl(): StudioKey | null {
  if (typeof window === "undefined") return null;
  const params = new URLSearchParams(window.location.search);
  const s = params.get("studio")?.toLowerCase();
  if (s === "list" || s === "suedstadt" || s === "südstadt") {
    return s === "südstadt" ? "suedstadt" : (s as StudioKey);
  }
  return null;
}

// Formular-Vorbefüllung aus URL
export function getPrefillFromUrl() {
  if (typeof window === "undefined")
    return {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      directAbschluss: false,
    };
  const params = new URLSearchParams(window.location.search);
  return {
    firstName: params.get("first_name") || "",
    lastName: params.get("last_name") || "",
    email: params.get("email") || "",
    phone: params.get("phone") || "",
    directAbschluss: params.get("abschluss") === "1" || params.has("abschluss"),
  };
}

// GHL-Webhook: Lead in den richtigen Sub-Account
// GET-Parameter, mehrere Tags als tag1, tag2 …
export function sendLeadWebhook(
  studio: StudioConfig,
  data: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    kennung: string;
  },
) {
  const params = new URLSearchParams();
  params.set("first_name", data.firstName);
  params.set("last_name", data.lastName);
  params.set("full_name", `${data.firstName} ${data.lastName}`.trim());
  params.set("email", data.email);
  params.set("phone", data.phone);
  params.set("studio", studio.label);
  params.set("studio_id", studio.studioId);
  params.set("studioKey", studio.key);
  params.set("kennung", data.kennung);
  params.set("tag1", TAGS.lead);
  params.set("intent", "3-monate-gratis");
  params.set("angebot_name", "3 Monate GRATIS Trainieren");
  params.set("angebot_wert", "259,95");

  const url = `${studio.webhookBase}/${studio.leadTrigger}?${params.toString()}`;
  // fire-and-forget; kein Beacon nötig, aber robust gegen Page-Unload
  try {
    navigator.sendBeacon(url);
  } catch {
    fetch(url, { mode: "no-cors" }).catch(() => {});
  }
}

// GHL-Webhook: Abschluss in den richtigen Sub-Account
export function sendAbschlussWebhook(
  studio: StudioConfig,
  data: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    kennung: string;
  },
) {
  const params = new URLSearchParams();
  params.set("event", "abschluss-online");
  params.set("fullName", `${data.firstName} ${data.lastName}`.trim());
  params.set("firstName", data.firstName);
  params.set("lastName", data.lastName);
  params.set("email", data.email);
  params.set("phone", data.phone);
  params.set("studio", studio.label);
  params.set("studioKey", studio.key);
  params.set("studioId", studio.studioId);
  params.set("kennung", data.kennung);
  params.set("source", "landingpage-abschluss");
  params.set("tag1", TAGS.abschluss);

  const url = `${studio.webhookBase}/${studio.abschlussTrigger}?${params.toString()}`;
  try {
    navigator.sendBeacon(url);
  } catch {
    fetch(url, { mode: "no-cors" }).catch(() => {});
  }
}

// MagicLine · Vertrag anlegen (Echtabschluss direkt aus dem Browser)
// POST /connect/v1/rate-bundle – ohne Authorization-Header
export async function createMagicLineContract(
  studio: StudioConfig,
  data: {
    gender: "MALE" | "FEMALE" | "DIVERSE";
    firstName: string;
    lastName: string;
    dateOfBirth: string; // YYYY-MM-DD
    email: string;
    street: string;
    houseNumber: string;
    zipCode: string;
    city: string;
    iban: string;
    accountHolder: string;
    phone: string;
  },
): Promise<{ ok: boolean; error?: string }> {
  const api = "https://sportsundspa.api.magicline.com";
  const startDate = new Date().toISOString().slice(0, 10);

  const payload = {
    studioId: Number(studio.studioId),
    contract: {
      rateBundleTermId: Number(studio.rateBundleTermId),
      startDate,
    },
    customer: {
      gender: data.gender,
      firstname: data.firstName,
      lastname: data.lastName,
      dateOfBirth: data.dateOfBirth,
      email: data.email,
      street: data.street,
      houseNumber: data.houseNumber,
      zipCode: data.zipCode,
      city: data.city,
      countryCode: "DE",
      language: "de",
      locale: "de_DE",
      paymentChoice: "DIRECT_DEBIT",
      bankAccount: {
        accountHolder: data.accountHolder,
        iban: data.iban.replace(/\s+/g, ""),
      },
      telephone_mobile: data.phone,
    },
  };

  try {
    const res = await fetch(`${api}/connect/v1/rate-bundle`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      return {
        ok: false,
        error: `MagicLine ${res.status}: ${text.slice(0, 200)}`,
      };
    }
    return { ok: true };
  } catch (err) {
    return {
      ok: false,
      error: err instanceof Error ? err.message : "Netzwerkfehler",
    };
  }
}

// PLZ → Ort ergänzen (openplzapi, kostenlos, ohne Key)
export async function lookupCity(zipCode: string): Promise<string> {
  if (!zipCode || zipCode.length < 4) return "";
  try {
    const res = await fetch(
      `https://openplzapi.org/de/Localities?postalCode=${encodeURIComponent(zipCode)}`,
    );
    if (!res.ok) return "";
    const data = await res.json();
    return Array.isArray(data) && data[0]?.name ? data[0].name : "";
  } catch {
    return "";
  }
}
